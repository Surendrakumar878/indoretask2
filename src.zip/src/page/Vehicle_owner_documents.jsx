import { Button, Card, Modal } from 'antd';
import React, { useEffect, useRef, useState } from 'react'
import Pdftoprint from './Pdftoprint';
import axios from 'axios';
import { useReactToPrint } from 'react-to-print';

const Vehicle_owner_documents = () => {
    const conponentPDF= useRef();
    const [userData, setUserdata]= useState([]);
  
    useEffect( ()=>{
        const registerUserdata= async()=>{
         axios.get("http://localhost:4000/Vehicle")  
         .then(res=>setUserdata(res.data.data) )
         .catch(error=>console.log(error)); 

        }
        registerUserdata();
    },[]);

    const generatePDF= useReactToPrint({
        content: ()=>conponentPDF.current,
        documentTitle:"Userdata",
        onAfterPrint:()=>alert("Data saved in PDF")
    });
       console.log(userData)

    const [visible, setVisible] = useState(false);
    const [visible1, setVisible1] = useState(false);

  const showModal = () => {
    // setVisible(true);
    setVisible1(true);
  };
  const showModal1 = () => {
    // setVisible(true);
    setVisible(true);
  };

  const handleOk = (e) => {
    console.log(e);
    setVisible(false);
    setVisible1(false);
  };

  const handleCancel = (e) => {
    console.log(e);
    setVisible(false);
    setVisible1(false);
  };

  return (
    <div className=' m-auto  '>
<div className="mt-2 bg-[#151B54] mb-4 text-center text-fuchsia-50 w-full">  Vehicle / owner Documents </div> 
<div className='bg-slate-400 p-7 w-96 m-auto'>
<Card className='w-80' hoverable bodyStyle={{ padding: "0"}}>
<div className="card_menu" >  User details </div> 


<div className='w-[96%] m-auto  flex-col flex gap-5 text-center '>
<div>

      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>GST Certificate</Button>
</div>
<div>
    
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>TDS Declaration</Button>
</div>
<div>
    
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>FasTag Card</Button>
</div>
<div>
    
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>Owner PAN Card</Button>
</div>
<div>
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>Registration Book (RC)</Button>
    
</div>
<div>
    
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal}>Owner Aadhar Card</Button>
</div>
<div>
    
      <Button className='bg-blue-950 w-48' type="primary" onClick={showModal1}>Vehicle Picture</Button>
</div>

</div>

<div className="card_menu my-10">  Vehicle Documents </div> 

<div>

    <div className='w-[96%] m-auto  py-10 flex flex-col gap-5'>
    <div>
    
    <Button className='bg-blue-950' type="primary" onClick={showModal}>FITNESS</Button>
    </div>
    <div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>ROADTAX </Button>
</div>
<div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>INSURANCE COMPANY</Button>
</div>
<div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>STATE PERMIT </Button>
    </div>
      <div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>ALL INDIA PERMIT </Button>
</div>
<div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>PUC</Button>
</div>
<div>
    
      <Button className='bg-blue-950' type="primary" onClick={showModal}>GREENTAX</Button>
</div>


    </div>
    <div className='w-full m-auto text-center my-10'>

<Button className='m-auto w-40' onClick={showModal}> All view </Button>
    </div>


</div>
      <Modal
        title="Basic Modal"
        visible={visible}
        onOk={handleOk}
        onCancel={handleCancel}

        width={"80%"}
      >
      <Pdftoprint />
      </Modal>

      <Modal
        title="Basic Modal"
        visible={visible1}
        onOk={handleOk}
        onCancel={handleCancel}

        width={"80%"}
      >
<div ref={conponentPDF}>


<div className='my-40'>

<Pdftoprint vis={false} />
</div>
     
<div className='my-40'>

<Pdftoprint vis={false} />
</div>
        
     


</div>
  <button className="btn btn-success bg-blue-400 py-3 px-2 w-28 text-xl mt-10 rounded-lg text-white " onClick={ generatePDF}>Print</button> 

     


      </Modal>
      </Card>
      </div>
    </div>

  )
}

export default Vehicle_owner_documents
